package Iniciar;

import View.*;
import Model.*;
public class InicarJogo {

	public static void main(String[] args) {
		Regras regras = new Regras(0,2);
		Dados a = new Dados();
		
		TelaInicial inicial = new TelaInicial();
		 			// TODO Auto-generated method stub
		 inicial.setVisible(true);

		 
		 
			 
	}

}
